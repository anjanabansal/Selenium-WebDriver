package po;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import utility.utility;

public class Signup {

	WebDriver driver;
	By signup = By.xpath(utility.getObjectFromPropertiesFile("signupEmail"));
	By signupPwd = By.xpath(utility.getObjectFromPropertiesFile("signupPwd"));
	By signupSubmit = By.xpath(utility.getObjectFromPropertiesFile("signupSubmit"));
//	By signup = By.xpath(utility.getDataFromPropertiesFile("signupEmail"));
//	By signup = By.xpath(utility.getDataFromPropertiesFile("signupEmail"));
	
	
	public void performSignup() {
		driver.findElement(signup).sendKeys(utility.getDataFromPropertiesFile("email"));
		driver.findElement(signupPwd).sendKeys(utility.getDataFromPropertiesFile("pwd"));
		driver.findElement(signupSubmit).click();
		WebDriverWait wait  = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.visibilityOfElementLocated(signup));
	}
	
}
