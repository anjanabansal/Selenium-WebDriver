package tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentReporter;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import po.Signup;
//import po.Signup;
public class testsignup {
	
	WebDriver driver;
	Signup s = new Signup();
	
	 
//	 extent.attachReporter(spark);
//	 extent.attachReporter(spark);
	@BeforeClass
	public void setup() {
		driver = new ChromeDriver();
		driver.manage().window().maximize();
	}
	@Test
	public void testsignup() {
		
		s.performSignup();
		System.out.println("hi inside testsingnup");
		Assert.assertEquals(false, false);
	}

}
